import os
import json
from flask import Flask, request, jsonify
from google.oauth2 import service_account
from googleapiclient.discovery import build

app = Flask(__name__)

DOCUMENT_ID = os.environ.get('DOCUMENT_ID')
API_SECRET = os.environ.get('API_SECRET')
service_account_info = json.loads(os.environ.get('GOOGLE_CREDENTIALS'))
SCOPES = ['https://www.googleapis.com/auth/documents']
creds = service_account.Credentials.from_service_account_info(service_account_info, scopes=SCOPES)
docs_service = build('docs', 'v1', credentials=creds)

@app.route('/add_note', methods=['POST'])
def add_note():
    data = request.get_json()
    note = data.get("text")
    token = data.get("token")

    if token != API_SECRET:
        return jsonify({"error": "Unauthorized"}), 401
    if not note:
        return jsonify({"error": "Missing 'text'"}), 400

    requests = [{
        'insertText': {
            'location': {'index': 1},
            'text': f'\n🟢 {note}\n'
        }
    }]
    try:
        docs_service.documents().batchUpdate(
            documentId=DOCUMENT_ID,
            body={'requests': requests}
        ).execute()
        return jsonify({"success": True})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)
