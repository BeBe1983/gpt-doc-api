# GPT Doc API

This Flask app allows you to receive insights and append them to a shared Google Doc.

## To deploy on Render:
1. Upload this zip.
2. Set the following environment variables:
   - DOCUMENT_ID
   - API_SECRET
   - GOOGLE_CREDENTIALS (contents of credentials.json)
3. Use `/add_note` as a POST endpoint.
